// Глобальные переменные
let currentGame = null;
let theme = 'light';
let avatarUrl = 'https://via.placeholder.com/32';

// Проверяем состояние входа при загрузке
document.addEventListener('DOMContentLoaded', function() {
    // Загружаем сохранённые настройки
    const savedTheme = localStorage.getItem('theme') || 'light';
    const savedAvatar = localStorage.getItem('avatar') || 'https://via.placeholder.com/32';
    const isLoggedIn = localStorage.getItem('isLoggedIn') === 'true';
    const username = localStorage.getItem('username') || 'Пользователь';
    const email = localStorage.getItem('email') || '';

    theme = savedTheme;
    avatarUrl = savedAvatar;

    // Применяем тему
    document.body.className = `${theme}-theme`;
    if (theme === 'dark') {
        document.querySelector('.theme-toggle input').checked = true;
    }

    // Устанавливаем аватар и имя
    if (isLoggedIn) {
        document.getElementById('guest-menu').style.display = 'none';
        document.getElementById('user-avatar').style.display = 'flex';
        document.getElementById('username').textContent = username;
        document.getElementById('avatar-img').src = avatarUrl;
    } else {
        document.getElementById('guest-menu').style.display = 'flex';
        document.getElementById('user-avatar').style.display = 'none';
    }

    // Обработчики кнопок входа/регистрации
    document.getElementById('login-btn').addEventListener('click', function() {
        openModal('login-modal');
    });

    document.getElementById('register-btn').addEventListener('click', function() {
        openModal('register-modal');
    });

    // Обработчики форм
    document.getElementById('login-form').addEventListener('submit', function(e) {
        e.preventDefault();
        const email = document.getElementById('login-email').value;
        const password = document.getElementById('login-password').value;

        const users = JSON.parse(localStorage.getItem('users') || '[]');
        const user = users.find(u => u.email === email && u.password === password);

        if (user) {
            localStorage.setItem('isLoggedIn', 'true');
            localStorage.setItem('username', user.name);
            localStorage.setItem('email', user.email);
            localStorage.setItem('avatar', user.avatar || avatarUrl);
            closeModal('login-modal');
            showNotification('Вход выполнен!');
            location.reload();
        } else {
            showNotification('Неверный email или пароль', true);
        }
    });

    document.getElementById('register-form').addEventListener('submit', function(e) {
        e.preventDefault();
        const name = document.getElementById('register-name').value;
        const email = document.getElementById('register-email').value;
        const password = document.getElementById('register-password').value;
        const confirm = document.getElementById('register-confirm').value;

        if (!validateEmail(email)) {
            showNotification('Введите корректный email', true);
            return;
        }

        if (password !== confirm) {
            showNotification('Пароли не совпадают', true);
            return;
        }

        if (password.length < 6) {
            showNotification('Пароль должен быть не менее 6 символов', true);
            return;
        }

        const users = JSON.parse(localStorage.getItem('users') || '[]');
        if (users.find(u => u.email === email)) {
            showNotification('Пользователь с таким email уже существует', true);
            return;
        }

        if (users.find(u => u.name === name)) {
            showNotification('Пользователь с таким именем уже существует', true);
            return;
        }

        users.push({
            name,
            email,
            password,
            avatar: avatarUrl
        });
        localStorage.setItem('users', JSON.stringify(users));

        localStorage.setItem('isLoggedIn', 'true');
        localStorage.setItem('username', name);
        localStorage.setItem('email', email);
        localStorage.setItem('avatar', avatarUrl);

        closeModal('register-modal');
        showNotification('Регистрация успешна!');
        location.reload();
    });

    // Обработчики навигации
    document.querySelectorAll('.sidebar nav a').forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            const page = this.getAttribute('data-page');
            loadPage(page);
        });
    });

    // Обработчик поиска
    const searchInput = document.querySelector('.search-box input');
    searchInput.addEventListener('input', function() {
        const query = this.value.toLowerCase();
        if (query.length > 0) {
            const gameCards = document.querySelectorAll('.game-card');
            gameCards.forEach(card => {
                const title = card.querySelector('h3').textContent.toLowerCase();
                if (title.includes(query)) {
                    card.style.display = 'flex';
                } else {
                    card.style.display = 'none';
                }
            });
        } else {
            const gameCards = document.querySelectorAll('.game-card');
            gameCards.forEach(card => card.style.display = 'flex');
        }
    });

    // Загрузка начальной страницы
    loadPage('home');
});

function showNotification(message, isError = false) {
    const notification = document.getElementById('notification');
    notification.textContent = message;
    notification.className = 'notification';
    if (isError) {
        notification.classList.add('error');
    }
    notification.style.display = 'block';
    setTimeout(() => {
        notification.style.display = 'none';
    }, 3000);
}

function openModal(modalId) {
    document.getElementById(modalId).style.display = 'block';
}

function closeModal(modalId) {
    document.getElementById(modalId).style.display = 'none';
}

function validateEmail(email) {
    const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return re.test(email);
}

function loadPage(page) {
    // Сброс активного класса
    document.querySelectorAll('.sidebar nav a').forEach(link => {
        link.classList.remove('active');
    });

    // Установка активного класса
    document.querySelector(`[data-page="${page}"]`).classList.add('active');

    const contentArea = document.getElementById('content-area');

    switch(page) {
        case 'home':
            contentArea.innerHTML = `
                <div class="game-grid">
                    ${createGameCard('Змейка', '🐍', 'snake')}
                    ${createGameCard('Сапер', '💣', 'minesweeper')}
                    ${createGameCard('2048', '🔢', '2048')}
                    ${createGameCard('Шахматы', '♟️', 'chess')}
                    ${createDisabledGameCard('Пазлы', '🧩')}
                    ${createDisabledGameCard('Гонки', '🏎️')}
                    ${createDisabledGameCard('Квест', '🗺️')}
                    ${createDisabledGameCard('Стратегия', '⚔️')}
                </div>
            `;
            break;

        case 'leaderboard':
            loadLeaderboardPage();
            break;

        case 'support':
            contentArea.innerHTML = `
                <div class="game-container">
                    <h2>🛠️ Техническая поддержка</h2>
                    <p>Если у вас возникли проблемы или вопросы, напишите нам:</p>
                    <div style="margin-top: 20px;">
                        <strong>Email:</strong> support@gamehub.com<br>
                        <strong>Часы работы:</strong> Пн-Пт, 9:00–18:00<br>
                        <strong>Телефон:</strong> +7 (XXX) XXX-XX-XX<br>
                    </div>
                    <div style="margin-top: 20px;">
                        <button class="game-button">Написать в чат</button>
                    </div>
                </div>
            `;
            break;

        case 'settings':
            loadSettingsPage();
            break;

        case 'profile':
            loadProfilePage();
            break;
    }
}

function loadLeaderboardPage() {
    const users = JSON.parse(localStorage.getItem('leaderboard') || '[]');
    const contentArea = document.getElementById('content-area');

    contentArea.innerHTML = `
        <div class="game-container">
            <h2>🏆 Таблица рейтинга</h2>
            <div style="margin-top: 20px; text-align: left;">
                ${users.map((user, index) => `
                    <strong>${index + 1}. ${user.name}</strong> - ${user.score} очков<br>
                `).join('') || '<p>Нет данных</p>'}
            </div>
        </div>
    `;
}

function loadSettingsPage() {
    const contentArea = document.getElementById('content-area');

    contentArea.innerHTML = `
        <div class="settings-container">
            <h2>⚙️ Настройки</h2>

            <div class="settings-item">
                <label>Тема</label>
                <div class="theme-toggle">
                    <span>Светлая</span>
                    <input type="checkbox" id="theme-toggle">
                    <span>Тёмная</span>
                </div>
            </div>

            <div class="settings-item">
                <label>Уведомления</label>
                <input type="checkbox" id="notifications" checked>
            </div>

            <div class="settings-item">
                <label>Автосохранение</label>
                <input type="checkbox" id="autosave" checked>
            </div>

            <div style="margin-top: 20px; text-align: center;">
                <button class="game-button" onclick="saveSettings()">Сохранить настройки</button>
            </div>
        </div>
    `;

    // Обработчик смены темы
    document.getElementById('theme-toggle').addEventListener('change', function() {
        if (this.checked) {
            document.body.className = 'dark-theme';
            theme = 'dark';
        } else {
            document.body.className = 'light-theme';
            theme = 'light';
        }
        localStorage.setItem('theme', theme);
    });
}

function loadProfilePage() {
    const isLoggedIn = localStorage.getItem('isLoggedIn') === 'true';
    if (!isLoggedIn) {
        showNotification('Для доступа к профилю нужно войти в аккаунт', true);
        return;
    }

    const username = localStorage.getItem('username') || 'Пользователь';
    const email = localStorage.getItem('email') || 'user@example.com';
    const avatar = localStorage.getItem('avatar') || 'https://via.placeholder.com/32';
    const totalScore = parseInt(localStorage.getItem('totalScore')) || 0;
    const rank = parseInt(localStorage.getItem('rank')) || 100;

    const contentArea = document.getElementById('content-area');
    contentArea.innerHTML = `
        <div class="settings-container">
            <h2>👤 Профиль</h2>

            <div class="settings-item">
                <label>Аватар</label>
                <div style="display: flex; align-items: center; gap: 10px;">
                    <img class="avatar-preview" src="${avatar}" alt="Аватар">
                    <input type="file" id="profile-avatar-upload" accept="image/*">
                    <button class="game-button" onclick="updateAvatar()">Сохранить</button>
                </div>
            </div>

            <div class="settings-item">
                <label>Имя пользователя</label>
                <input type="text" id="profile-username" value="${username}" readonly style="background: #eee; cursor: not-allowed;">
            </div>

            <div class="settings-item">
                <label>Email</label>
                <div style="display: flex; gap: 10px;">
                    <input type="email" id="profile-email" value="${email}">
                    <button class="game-button" onclick="updateEmail()">Изменить</button>
                </div>
            </div>

            <div class="settings-item">
                <label>Пароль</label>
                <div style="display: flex; gap: 10px;">
                    <input type="password" id="profile-password" placeholder="Введите новый пароль">
                    <input type="password" id="profile-password-confirm" placeholder="Подтвердите пароль">
                    <button class="game-button" onclick="updatePassword()">Изменить</button>
                </div>
            </div>

            <div class="settings-item">
                <label>Общий счёт</label>
                <div class="score-container">${totalScore}</div>
            </div>

            <div class="settings-item">
                <label>Место в рейтинге</label>
                <div class="score-container">#${rank}</div>
            </div>

            <div style="margin-top: 20px; text-align: center;">
                <button class="game-button" onclick="logout()">Выйти из аккаунта</button>
            </div>
        </div>
    `;
}

function updateAvatar() {
    const input = document.getElementById('profile-avatar-upload');
    const file = input.files[0];
    if (file) {
        const reader = new FileReader();
        reader.onload = function(event) {
            const newAvatar = event.target.result;
            localStorage.setItem('avatar', newAvatar);
            document.getElementById('avatar-img').src = newAvatar;
            showNotification('Аватар обновлён!');
            loadProfilePage();
        };
        reader.readAsDataURL(file);
    }
}

function updateEmail() {
    const newEmail = document.getElementById('profile-email').value;
    if (!newEmail || !validateEmail(newEmail)) {
        showNotification('Введите корректный email', true);
        return;
    }

    const users = JSON.parse(localStorage.getItem('users') || '[]');
    const existingUser = users.find(u => u.email === newEmail && u.email !== localStorage.getItem('email'));
    if (existingUser) {
        showNotification('Пользователь с таким email уже существует', true);
        return;
    }

    localStorage.setItem('email', newEmail);
    showNotification('Email обновлён!');
    loadProfilePage();
}

function updatePassword() {
    const newPassword = document.getElementById('profile-password').value;
    const confirmPassword = document.getElementById('profile-password-confirm').value;

    if (!newPassword || newPassword.length < 6) {
        showNotification('Пароль должен быть не менее 6 символов', true);
        return;
    }

    if (newPassword !== confirmPassword) {
        showNotification('Пароли не совпадают', true);
        return;
    }

    const users = JSON.parse(localStorage.getItem('users') || '[]');
    const username = localStorage.getItem('username');
    const user = users.find(u => u.name === username);
    if (user) {
        user.password = newPassword;
        localStorage.setItem('users', JSON.stringify(users));
    }

    showNotification('Пароль обновлён!');
    document.getElementById('profile-password').value = '';
    document.getElementById('profile-password-confirm').value = '';
}

function logout() {
    localStorage.removeItem('isLoggedIn');
    localStorage.removeItem('username');
    localStorage.removeItem('email');
    localStorage.removeItem('avatar');
    showNotification('Вы вышли из аккаунта');
    location.reload();
}

function saveSettings() {
    localStorage.setItem('theme', theme);
    showNotification('Настройки сохранены!');
}

function createGameCard(title, icon, gameType) {
    return `
        <div class="game-card" onclick="loadGame('${gameType}')">
            <div class="icon">${icon}</div>
            <h3>${title}</h3>
        </div>
    `;
}

function createDisabledGameCard(title, icon) {
    return `
        <div class="game-card disabled-game">
            <div class="icon">${icon}</div>
            <h3>${title}</h3>
            <div class="coming-soon">В разработке</div>
        </div>
    `;
}

function loadGame(gameType) {
    const contentArea = document.getElementById('content-area');

    let gameContent = '';
    switch(gameType) {
        case 'snake':
            gameContent = createSnakeGame();
            break;

        case 'minesweeper':
            gameContent = createMinesweeperGame();
            break;

        case '2048':
            gameContent = create2048Game();
            break;

        case 'chess':
            gameContent = createChessGame();
            break;
    }

    contentArea.innerHTML = gameContent;
}

// 🐍 Змейка
function createSnakeGame() {
    return `
        <div class="game-container">
            <h2>🐍 Змейка</h2>
            <div class="difficulty-selector">
                <label>Сложность: </label>
                <div class="difficulty-buttons">
                    <button class="diff-btn active easy" data-difficulty="easy" onclick="setDifficulty('snake', 'easy')">Лёгкая</button>
                    <button class="diff-btn normal" data-difficulty="normal" onclick="setDifficulty('snake', 'normal')">Нормальная</button>
                    <button class="diff-btn hard" data-difficulty="hard" onclick="setDifficulty('snake', 'hard')">Сложная</button>
                </div>
            </div>
            <div class="score-display">Очки: <span id="snake-score">0</span></div>
            <div class="snake-game" id="snake-game"></div>
            <p>Управление: стрелками (↑↓←→)</p>
            <button class="game-button" onclick="startSnakeGame()">Начать игру</button>
        </div>
    `;
}

function setDifficulty(game, difficulty) {
    currentGameDifficulty = difficulty;

    // Обновляем активную кнопку
    const buttons = document.querySelectorAll('.diff-btn');
    buttons.forEach(btn => {
        if (btn.dataset.difficulty === difficulty) {
            btn.classList.add('active');
        } else {
            btn.classList.remove('active');
        }
    });
}

let snakeInterval;
let snakeScore = 0;
let snakeDirection = 'right';
let snakeBody = [{x: 10, y: 10}];
let food = {x: 15, y: 15};
let snakeSpeed = 150;

function startSnakeGame() {
    snakeScore = 0;
    snakeDirection = 'right';
    snakeBody = [{x: 10, y: 10}];
    placeFood();

    document.getElementById('snake-score').textContent = snakeScore;

    clearInterval(snakeInterval);

    if (currentGameDifficulty === 'easy') snakeSpeed = 200;
    else if (currentGameDifficulty === 'hard') snakeSpeed = 100;
    else snakeSpeed = 150;

    snakeInterval = setInterval(moveSnake, snakeSpeed);

    renderSnake();
}

function moveSnake() {
    const head = {...snakeBody[0]};

    switch(snakeDirection) {
        case 'up': head.y--; break;
        case 'down': head.y++; break;
        case 'left': head.x--; break;
        case 'right': head.x++; break;
    }

    if (head.x < 0 || head.x >= 16 || head.y < 0 || head.y >= 16) {
        gameOver();
        return;
    }

    for (let i = 0; i < snakeBody.length; i++) {
        if (snakeBody[i].x === head.x && snakeBody[i].y === head.y) {
            gameOver();
            return;
        }
    }

    if (head.x === food.x && head.y === food.y) {
        snakeScore++;
        document.getElementById('snake-score').textContent = snakeScore;
        updateProfileData(snakeScore);
        placeFood();
    } else {
        snakeBody.pop();
    }

    snakeBody.unshift(head);
    renderSnake();
}

function renderSnake() {
    const gameDiv = document.getElementById('snake-game');
    gameDiv.innerHTML = '';

    snakeBody.forEach((part, index) => {
        const cell = document.createElement('div');
        cell.style.left = part.x * 20 + 'px';
        cell.style.top = part.y * 20 + 'px';
        if (index === 0) {
            cell.className = 'snake-cell snake-head';
        } else {
            cell.className = 'snake-cell snake-body';
        }
        gameDiv.appendChild(cell);
    });

    const foodEl = document.createElement('div');
    foodEl.className = 'food';
    foodEl.style.left = food.x * 20 + 'px';
    foodEl.style.top = food.y * 20 + 'px';
    gameDiv.appendChild(foodEl);
}

function placeFood() {
    food = {
        x: Math.floor(Math.random() * 16),
        y: Math.floor(Math.random() * 16)
    };

    for (let part of snakeBody) {
        if (part.x === food.x && part.y === food.y) {
            placeFood();
            return;
        }
    }
}

function gameOver() {
    clearInterval(snakeInterval);
    showNotification('Игра окончена! Ваш счёт: ' + snakeScore);
}

document.addEventListener('keydown', function(e) {
    if (!snakeInterval) return;

    switch(e.key) {
        case 'ArrowUp':
            if (snakeDirection !== 'down') snakeDirection = 'up';
            break;
        case 'ArrowDown':
            if (snakeDirection !== 'up') snakeDirection = 'down';
            break;
        case 'ArrowLeft':
            if (snakeDirection !== 'right') snakeDirection = 'left';
            break;
        case 'ArrowRight':
            if (snakeDirection !== 'left') snakeDirection = 'right';
            break;
    }
});

// 💣 Сапер
function createMinesweeperGame() {
    return `
        <div class="game-container">
            <h2>💣 Сапер</h2>
            <div class="difficulty-selector">
                <label>Сложность: </label>
                <div class="difficulty-buttons">
                    <button class="diff-btn active easy" data-difficulty="easy" onclick="setDifficulty('minesweeper', 'easy')">Лёгкая</button>
                    <button class="diff-btn normal" data-difficulty="normal" onclick="setDifficulty('minesweeper', 'normal')">Нормальная</button>
                    <button class="diff-btn hard" data-difficulty="hard" onclick="setDifficulty('minesweeper', 'hard')">Сложная</button>
                </div>
            </div>
            <div class="minesweeper-grid" id="minesweeper-grid"></div>
            <p>ЛКМ — открывать ячейку, ПКМ — ставить флаг</p>
            <button class="game-button" onclick="initMinesweeper()">Начать игру</button>
        </div>
    `;
}

let minesweeperGrid = [];
let minesweeperSize = 10;
let minesweeperMines = 15;

function initMinesweeper() {
    if (currentGameDifficulty === 'easy') {
        minesweeperSize = 8;
        minesweeperMines = 10;
    } else if (currentGameDifficulty === 'hard') {
        minesweeperSize = 12;
        minesweeperMines = 20;
    } else {
        minesweeperSize = 10;
        minesweeperMines = 15;
    }

    const gridDiv = document.getElementById('minesweeper-grid');
    gridDiv.className = 'minesweeper-grid';
    if (currentGameDifficulty === 'easy') gridDiv.classList.add('easy');
    else if (currentGameDifficulty === 'hard') gridDiv.classList.add('hard');

    minesweeperGrid = [];
    for (let i = 0; i < minesweeperSize; i++) {
        minesweeperGrid[i] = [];
        for (let j = 0; j < minesweeperSize; j++) {
            minesweeperGrid[i][j] = {
                isMine: false,
                isRevealed: false,
                isFlagged: false,
                adjacentMines: 0
            };
        }
    }

    let minesPlaced = 0;
    while (minesPlaced < minesweeperMines) {
        const row = Math.floor(Math.random() * minesweeperSize);
        const col = Math.floor(Math.random() * minesweeperSize);
        if (!minesweeperGrid[row][col].isMine) {
            minesweeperGrid[row][col].isMine = true;
            minesPlaced++;
        }
    }

    for (let i = 0; i < minesweeperSize; i++) {
        for (let j = 0; j < minesweeperSize; j++) {
            if (!minesweeperGrid[i][j].isMine) {
                minesweeperGrid[i][j].adjacentMines = countAdjacentMines(i, j);
            }
        }
    }

    renderMinesweeper();
}

function countAdjacentMines(row, col) {
    let count = 0;
    for (let i = -1; i <= 1; i++) {
        for (let j = -1; j <= 1; j++) {
            const r = row + i;
            const c = col + j;
            if (r >= 0 && r < minesweeperSize && c >= 0 && c < minesweeperSize && minesweeperGrid[r][c].isMine) {
                count++;
            }
        }
    }
    return count;
}

function renderMinesweeper() {
    const gridDiv = document.getElementById('minesweeper-grid');
    gridDiv.innerHTML = '';

    for (let i = 0; i < minesweeperSize; i++) {
        for (let j = 0; j < minesweeperSize; j++) {
            const cell = document.createElement('div');
            cell.className = 'minesweeper-cell';
            cell.dataset.row = i;
            cell.dataset.col = j;

            if (minesweeperGrid[i][j].isRevealed) {
                cell.classList.add('revealed');
                if (minesweeperGrid[i][j].isMine) {
                    cell.classList.add('mine');
                    cell.textContent = '💣';
                } else if (minesweeperGrid[i][j].adjacentMines > 0) {
                    cell.classList.add(`number-${minesweeperGrid[i][j].adjacentMines}`);
                    cell.textContent = minesweeperGrid[i][j].adjacentMines;
                }
            } else if (minesweeperGrid[i][j].isFlagged) {
                cell.classList.add('flagged');
            }

            cell.addEventListener('click', function() {
                revealCell(i, j);
            });

            cell.addEventListener('contextmenu', function(e) {
                e.preventDefault();
                toggleFlag(i, j);
            });

            gridDiv.appendChild(cell);
        }
    }
}

function revealCell(row, col) {
    if (minesweeperGrid[row][col].isRevealed || minesweeperGrid[row][col].isFlagged) return;

    minesweeperGrid[row][col].isRevealed = true;

    if (minesweeperGrid[row][col].isMine) {
        gameOverMinesweeper();
        return;
    }

    if (minesweeperGrid[row][col].adjacentMines === 0) {
        for (let i = -1; i <= 1; i++) {
            for (let j = -1; j <= 1; j++) {
                const r = row + i;
                const c = col + j;
                if (r >= 0 && r < minesweeperSize && c >= 0 && c < minesweeperSize) {
                    if (!minesweeperGrid[r][c].isRevealed && !minesweeperGrid[r][c].isMine) {
                        revealCell(r, c);
                    }
                }
            }
        }
    }

    renderMinesweeper();
}

function toggleFlag(row, col) {
    if (minesweeperGrid[row][col].isRevealed) return;

    minesweeperGrid[row][col].isFlagged = !minesweeperGrid[row][col].isFlagged;
    renderMinesweeper();
}

function gameOverMinesweeper() {
    for (let i = 0; i < minesweeperSize; i++) {
        for (let j = 0; j < minesweeperSize; j++) {
            if (minesweeperGrid[i][j].isMine) {
                minesweeperGrid[i][j].isRevealed = true;
            }
        }
    }
    renderMinesweeper();
    showNotification('Вы проиграли! Вы нашли мину.');
}

// 🔢 2048
function create2048Game() {
    return `
        <div class="game-container">
            <h2>🔢 2048</h2>
            <div class="score-container">Счёт: <span id="score-2048">0</span></div>
            <div class="grid-2048" id="grid-2048"></div>
            <p>Используйте стрелки для перемещения плиток</p>
            <button class="game-button" onclick="init2048()">Начать игру</button>
        </div>
    `;
}

let grid = [];
let score = 0;

function init2048() {
    grid = [];
    score = 0;
    document.getElementById('content-area').querySelector('.game-container').innerHTML = `
        <h2>🔢 2048</h2>
        <div class="score-container">Счёт: <span id="score-2048">0</span></div>
        <div class="grid-2048" id="grid-2048"></div>
        <p>Используйте стрелки для перемещения плиток</p>
        <button class="game-button" onclick="init2048()">Новая игра</button>
    `;

    for (let i = 0; i < 4; i++) {
        grid[i] = [0, 0, 0, 0];
    }

    addRandomTile();
    addRandomTile();
    render2048WithAnimation();
}

function addRandomTile() {
    const emptyCells = [];
    for (let i = 0; i < 4; i++) {
        for (let j = 0; j < 4; j++) {
            if (grid[i][j] === 0) {
                emptyCells.push({row: i, col: j});
            }
        }
    }

    if (emptyCells.length > 0) {
        const randomCell = emptyCells[Math.floor(Math.random() * emptyCells.length)];
        grid[randomCell.row][randomCell.col] = Math.random() < 0.9 ? 2 : 4;
    }
}

function render2048WithAnimation() {
    const gridDiv = document.getElementById('grid-2048');
    gridDiv.innerHTML = '';

    for (let i = 0; i < 4; i++) {
        for (let j = 0; j < 4; j++) {
            const tile = document.createElement('div');
            tile.className = 'tile';
            if (grid[i][j] > 0) {
                tile.classList.add(`tile-${grid[i][j]}`);
                tile.textContent = grid[i][j];
            }
            gridDiv.appendChild(tile);
        }
    }

    // Обновляем счёт
    document.getElementById('score-2048').textContent = score;
    updateProfileData(score);

    // Анимация: добавляем классы для новых плиток
    setTimeout(() => {
        const tiles = gridDiv.querySelectorAll('.tile');
        tiles.forEach((tile, index) => {
            if (tile.textContent !== '0' && tile.textContent !== '') {
                tile.classList.add('tile-new');
                setTimeout(() => tile.classList.remove('tile-new'), 200);
            }
        });
    }, 10);
}

function move(direction) {
    let moved = false;

    if (direction === 'left') {
        for (let i = 0; i < 4; i++) {
            let row = [...grid[i]];
            let newRow = slideAndMerge(row);
            if (JSON.stringify(row) !== JSON.stringify(newRow)) {
                moved = true;
                grid[i] = newRow;
            }
        }
    } else if (direction === 'right') {
        for (let i = 0; i < 4; i++) {
            let row = [...grid[i]].reverse();
            let newRow = slideAndMerge(row);
            newRow.reverse();
            if (JSON.stringify(grid[i]) !== JSON.stringify(newRow)) {
                moved = true;
                grid[i] = newRow;
            }
        }
    } else if (direction === 'up') {
        for (let j = 0; j < 4; j++) {
            let col = [grid[0][j], grid[1][j], grid[2][j], grid[3][j]];
            let newCol = slideAndMerge(col);
            if (JSON.stringify(col) !== JSON.stringify(newCol)) {
                moved = true;
                for (let i = 0; i < 4; i++) {
                    grid[i][j] = newCol[i];
                }
            }
        }
    } else if (direction === 'down') {
        for (let j = 0; j < 4; j++) {
            let col = [grid[3][j], grid[2][j], grid[1][j], grid[0][j]];
            let newCol = slideAndMerge(col);
            newCol.reverse();
            if (JSON.stringify([grid[0][j], grid[1][j], grid[2][j], grid[3][j]]) !== JSON.stringify(newCol)) {
                moved = true;
                for (let i = 0; i < 4; i++) {
                    grid[i][j] = newCol[i];
                }
            }
        }
    }

    if (moved) {
        addRandomTile();
        render2048WithAnimation();
        checkGameOver();
    }
}

function slideAndMerge(arr) {
    let result = arr.filter(x => x > 0);
    for (let i = 0; i < result.length - 1; i++) {
        if (result[i] === result[i + 1]) {
            result[i] *= 2;
            score += result[i];
            result.splice(i + 1, 1);
        }
    }
    while (result.length < 4) {
        result.push(0);
    }
    return result;
}

function checkGameOver() {
    for (let i = 0; i < 4; i++) {
        for (let j = 0; j < 4; j++) {
            if (grid[i][j] === 0) return;
        }
    }

    for (let i = 0; i < 4; i++) {
        for (let j = 0; j < 4; j++) {
            if (j < 3 && grid[i][j] === grid[i][j + 1]) return;
            if (i < 3 && grid[i][j] === grid[i + 1][j]) return;
        }
    }

    showNotification('Игра окончена! Ваш счёт: ' + score);
}

document.addEventListener('keydown', function(e) {
    if (!grid || grid.length === 0) return;

    switch(e.key) {
        case 'ArrowLeft':
            move('left');
            break;
        case 'ArrowRight':
            move('right');
            break;
        case 'ArrowUp':
            move('up');
            break;
        case 'ArrowDown':
            move('down');
            break;
    }
});

// ♟️ ШАХМАТЫ — МУЛЬТИПЛЕЕР + БОТ
let chessBoard = [];
let selectedPiece = null;
let currentPlayer = 'w';
let castlingRights = {
    w: { kingSide: true, queenSide: true },
    b: { kingSide: true, queenSide: true }
};
let enPassantTarget = null;
let isGameVsBot = false;

function createChessGame() {
    return `
        <div class="game-container">
            <h2>♟️ Шахматы</h2>
            <div class="difficulty-selector">
                <label>Режим: </label>
                <div class="difficulty-buttons">
                    <button class="diff-btn active" data-mode="pvp" onclick="setChessMode('pvp')">Игрок против игрока</button>
                    <button class="diff-btn" data-mode="bot" onclick="setChessMode('bot')">Игрок против бота</button>
                </div>
            </div>
            <div id="difficulty-select" style="display: none; margin-top: 10px;">
                <label>Сложность: </label>
                <div class="difficulty-buttons">
                    <button class="diff-btn active easy" data-difficulty="easy" onclick="setBotDifficulty('easy')">Лёгкая</button>
                    <button class="diff-btn normal" data-difficulty="normal" onclick="setBotDifficulty('normal')">Нормальная</button>
                    <button class="diff-btn hard" data-difficulty="hard" onclick="setBotDifficulty('hard')">Сложная</button>
                </div>
            </div>
            <div class="chess-board" id="chess-board"></div>
            <p>Ходит: <span id="current-player">Белые</span></p>
            <button class="game-button" onclick="initChess()">Начать игру</button>
        </div>
    `;
}

function setChessMode(mode) {
    if (mode === 'bot') {
        document.getElementById('difficulty-select').style.display = 'block';
        isGameVsBot = true;
    } else {
        document.getElementById('difficulty-select').style.display = 'none';
        isGameVsBot = false;
    }

    // Обновляем активную кнопку
    const buttons = document.querySelectorAll('.diff-btn[data-mode]');
    buttons.forEach(btn => {
        if (btn.dataset.mode === mode) {
            btn.classList.add('active');
        } else {
            btn.classList.remove('active');
        }
    });
}

function setBotDifficulty(difficulty) {
    currentGameDifficulty = difficulty;

    // Обновляем активную кнопку
    const buttons = document.querySelectorAll('#difficulty-select .diff-btn');
    buttons.forEach(btn => {
        if (btn.dataset.difficulty === difficulty) {
            btn.classList.add('active');
        } else {
            btn.classList.remove('active');
        }
    });
}

function initChess() {
    chessBoard = Array(8).fill().map(() => Array(8).fill(null));

    const setupRow = (row, color) => {
        chessBoard[row][0] = { type: 'r', color };
        chessBoard[row][1] = { type: 'n', color };
        chessBoard[row][2] = { type: 'b', color };
        chessBoard[row][3] = { type: 'q', color };
        chessBoard[row][4] = { type: 'k', color };
        chessBoard[row][5] = { type: 'b', color };
        chessBoard[row][6] = { type: 'n', color };
        chessBoard[row][7] = { type: 'r', color };
    };

    setupRow(0, 'b');
    setupRow(7, 'w');

    for (let i = 0; i < 8; i++) {
        chessBoard[1][i] = { type: 'p', color: 'b' };
        chessBoard[6][i] = { type: 'p', color: 'w' };
    }

    currentPlayer = 'w';
    castlingRights = {
        w: { kingSide: true, queenSide: true },
        b: { kingSide: true, queenSide: true }
    };
    enPassantTarget = null;

    renderChess();
}

const pieceSymbols = {
    'k': { w: '♔', b: '♚' },
    'q': { w: '♕', b: '♛' },
    'r': { w: '♖', b: '♜' },
    'b': { w: '♗', b: '♝' },
    'n': { w: '♘', b: '♞' },
    'p': { w: '♙', b: '♟' }
};

function renderChess() {
    const container = document.getElementById('content-area').querySelector('.game-container');
    container.innerHTML = `
        <h2>♟️ Шахматы</h2>
        <div class="difficulty-selector">
            <label>Режим: </label>
            <div class="difficulty-buttons">
                <button class="diff-btn active" data-mode="pvp" onclick="setChessMode('pvp')">Игрок против игрока</button>
                <button class="diff-btn" data-mode="bot" onclick="setChessMode('bot')">Игрок против бота</button>
            </div>
        </div>
        <div id="difficulty-select" style="display: none; margin-top: 10px;">
            <label>Сложность: </label>
            <div class="difficulty-buttons">
                <button class="diff-btn active easy" data-difficulty="easy" onclick="setBotDifficulty('easy')">Лёгкая</button>
                <button class="diff-btn normal" data-difficulty="normal" onclick="setBotDifficulty('normal')">Нормальная</button>
                <button class="diff-btn hard" data-difficulty="hard" onclick="setBotDifficulty('hard')">Сложная</button>
            </div>
        </div>
        <div class="chess-board" id="chess-board"></div>
        <p>Ходит: <span id="current-player" style="color: ${currentPlayer === 'w' ? '#3498db' : '#e74c3c'};">
            ${currentPlayer === 'w' ? 'Белые' : 'Чёрные'}
        </span></p>
        <button class="game-button" onclick="initChess()">Новая игра</button>
    `;

    if (isGameVsBot) {
        document.getElementById('difficulty-select').style.display = 'block';
    }

    // Устанавливаем активные кнопки
    const modeButtons = document.querySelectorAll('.diff-btn[data-mode]');
    modeButtons.forEach(btn => {
        if (btn.dataset.mode === (isGameVsBot ? 'bot' : 'pvp')) {
            btn.classList.add('active');
        } else {
            btn.classList.remove('active');
        }
    });

    const diffButtons = document.querySelectorAll('#difficulty-select .diff-btn');
    diffButtons.forEach(btn => {
        if (btn.dataset.difficulty === currentGameDifficulty) {
            btn.classList.add('active');
        } else {
            btn.classList.remove('active');
        }
    });

    const boardDiv = document.getElementById('chess-board');
    boardDiv.innerHTML = '';

    for (let row = 0; row < 8; row++) {
        for (let col = 0; col < 8; col++) {
            const square = document.createElement('div');
            square.className = 'chess-square';
            if ((row + col) % 2 === 1) square.classList.add('dark');

            square.dataset.row = row;
            square.dataset.col = col;

            const piece = chessBoard[row][col];
            if (piece) {
                square.textContent = pieceSymbols[piece.type][piece.color];
            }

            square.addEventListener('click', () => handleChessClick(row, col));
            boardDiv.appendChild(square);
        }
    }

    if (selectedPiece) {
        highlightValidMoves(selectedPiece.row, selectedPiece.col);
    }

    if (isGameVsBot && currentPlayer === 'b') {
        setTimeout(() => botMove(), 500);
    }
}

function handleChessClick(row, col) {
    if (isGameVsBot && currentPlayer === 'b') return;

    if (selectedPiece) {
        const fromRow = selectedPiece.row;
        const fromCol = selectedPiece.col;
        const toRow = row;
        const toCol = col;

        const piece = chessBoard[fromRow][fromCol];
        if (!piece || piece.color !== currentPlayer) {
            selectedPiece = null;
            renderChess();
            return;
        }

        const validMoves = getValidMoves(fromRow, fromCol);
        const isValid = validMoves.some(move => move.row === toRow && move.col === toCol);

        if (isValid) {
            makeMove(fromRow, fromCol, toRow, toCol);
            currentPlayer = currentPlayer === 'w' ? 'b' : 'w';

            if (isGameVsBot && currentPlayer === 'b') {
                setTimeout(() => botMove(), 500);
            }
        }

        selectedPiece = null;
        renderChess();
    } else {
        const piece = chessBoard[row][col];
        if (piece && piece.color === currentPlayer) {
            selectedPiece = { row, col };
            renderChess();
        }
    }
}

let isBotThinking = false;

function botMove() {
    if (isBotThinking) return; // Защита от двойного хода
    isBotThinking = true;

    let moves = [];
    for (let row = 0; row < 8; row++) {
        for (let col = 0; col < 8; col++) {
            const piece = chessBoard[row][col];
            if (piece && piece.color === 'b') {
                const validMoves = getValidMoves(row, col);
                for (let move of validMoves) {
                    moves.push({ from: { row, col }, to: move });
                }
            }
        }
    }

    if (moves.length === 0) {
        showNotification('Шах и мат! Белые победили.');
        isBotThinking = false;
        return;
    }

    const randomMove = moves[Math.floor(Math.random() * moves.length)];
    const { from, to } = randomMove;

    makeMove(from.row, from.col, to.row, to.col);
    currentPlayer = 'w';
    isBotThinking = false; // Сброс флага
    renderChess();
}

function getValidMoves(row, col) {
    const piece = chessBoard[row][col];
    if (!piece) return [];

    let moves = [];
    switch (piece.type) {
        case 'p': moves = getPawnMoves(row, col, piece.color); break;
        case 'r': moves = getRookMoves(row, col, piece.color); break;
        case 'n': moves = getKnightMoves(row, col, piece.color); break;
        case 'b': moves = getBishopMoves(row, col, piece.color); break;
        case 'q': moves = getQueenMoves(row, col, piece.color); break;
        case 'k': moves = getKingMoves(row, col, piece.color); break;
    }

    return moves.filter(move => !wouldBeInCheck(row, col, move.row, move.col));
}

function getPawnMoves(row, col, color) {
    const moves = [];
    const direction = color === 'w' ? -1 : 1;
    const startRow = color === 'w' ? 6 : 1;

    if (isInBounds(row + direction, col) && !chessBoard[row + direction][col]) {
        moves.push({ row: row + direction, col });
        if (row === startRow && !chessBoard[row + 2 * direction][col]) {
            moves.push({ row: row + 2 * direction, col });
        }
    }

    for (let offset of [-1, 1]) {
        const newCol = col + offset;
        if (isInBounds(row + direction, newCol)) {
            const target = chessBoard[row + direction][newCol];
            if (target && target.color !== color) {
                moves.push({ row: row + direction, col: newCol });
            }
            if (enPassantTarget && enPassantTarget.row === row + direction && enPassantTarget.col === newCol) {
                moves.push({ row: row + direction, col: newCol });
            }
        }
    }

    return moves;
}

function getRookMoves(row, col, color) {
    return getSlidingMoves(row, col, color, [[0,1], [1,0], [0,-1], [-1,0]]);
}

function getBishopMoves(row, col, color) {
    return getSlidingMoves(row, col, color, [[1,1], [1,-1], [-1,1], [-1,-1]]);
}

function getQueenMoves(row, col, color) {
    return [
        ...getRookMoves(row, col, color),
        ...getBishopMoves(row, col, color)
    ];
}

function getKnightMoves(row, col, color) {
    const moves = [];
    const offsets = [[-2,-1], [-2,1], [-1,-2], [-1,2], [1,-2], [1,2], [2,-1], [2,1]];
    for (let [dr, dc] of offsets) {
        const newRow = row + dr;
        const newCol = col + dc;
        if (isInBounds(newRow, newCol)) {
            const target = chessBoard[newRow][newCol];
            if (!target || target.color !== color) {
                moves.push({ row: newRow, col: newCol });
            }
        }
    }
    return moves;
}

function getKingMoves(row, col, color) {
    const moves = [];
    for (let dr = -1; dr <= 1; dr++) {
        for (let dc = -1; dc <= 1; dc++) {
            if (dr === 0 && dc === 0) continue;
            const newRow = row + dr;
            const newCol = col + dc;
            if (isInBounds(newRow, newCol)) {
                const target = chessBoard[newRow][newCol];
                if (!target || target.color !== color) {
                    moves.push({ row: newRow, col: newCol });
                }
            }
        }
    }

    if (color === currentPlayer && !isInCheck(color)) {
        const kingSide = castlingRights[color].kingSide;
        const queenSide = castlingRights[color].queenSide;

        const row = color === 'w' ? 7 : 0;

        if (kingSide && !chessBoard[row][5] && !chessBoard[row][6] && !isSquareAttacked(row, 4, color) && !isSquareAttacked(row, 5, color)) {
            moves.push({ row, col: 6 });
        }

        if (queenSide && !chessBoard[row][1] && !chessBoard[row][2] && !chessBoard[row][3] && !isSquareAttacked(row, 4, color) && !isSquareAttacked(row, 3, color)) {
            moves.push({ row, col: 2 });
        }
    }

    return moves;
}

function getSlidingMoves(row, col, color, directions) {
    const moves = [];
    for (let [dr, dc] of directions) {
        let r = row + dr;
        let c = col + dc;
        while (isInBounds(r, c)) {
            const target = chessBoard[r][c];
            if (!target) {
                moves.push({ row: r, col: c });
            } else {
                if (target.color !== color) {
                    moves.push({ row: r, col: c });
                }
                break;
            }
            r += dr;
            c += dc;
        }
    }
    return moves;
}

function isInBounds(row, col) {
    return row >= 0 && row < 8 && col >= 0 && col < 8;
}

function isInCheck(color) {
    const kingPos = findKing(color);
    return isSquareAttacked(kingPos.row, kingPos.col, color);
}

function isSquareAttacked(row, col, color) {
    const opponent = color === 'w' ? 'b' : 'w';

    const pawnDir = color === 'w' ? 1 : -1;
    for (let dc of [-1, 1]) {
        if (isInBounds(row + pawnDir, col + dc)) {
            const piece = chessBoard[row + pawnDir][col + dc];
            if (piece && piece.type === 'p' && piece.color === opponent) return true;
        }
    }

    const knightOffsets = [[-2,-1], [-2,1], [-1,-2], [-1,2], [1,-2], [1,2], [2,-1], [2,1]];
    for (let [dr, dc] of knightOffsets) {
        const r = row + dr;
        const c = col + dc;
        if (isInBounds(r, c)) {
            const piece = chessBoard[r][c];
            if (piece && piece.type === 'n' && piece.color === opponent) return true;
        }
    }

    const rookDirs = [[0,1], [1,0], [0,-1], [-1,0]];
    for (let [dr, dc] of rookDirs) {
        let r = row + dr;
        let c = col + dc;
        while (isInBounds(r, c)) {
            const piece = chessBoard[r][c];
            if (piece) {
                if (piece.color === opponent && (piece.type === 'r' || piece.type === 'q')) return true;
                break;
            }
            r += dr;
            c += dc;
        }
    }

    const bishopDirs = [[1,1], [1,-1], [-1,1], [-1,-1]];
    for (let [dr, dc] of bishopDirs) {
        let r = row + dr;
        let c = col + dc;
        while (isInBounds(r, c)) {
            const piece = chessBoard[r][c];
            if (piece) {
                if (piece.color === opponent && (piece.type === 'b' || piece.type === 'q')) return true;
                break;
            }
            r += dr;
            c += dc;
        }
    }

    for (let dr = -1; dr <= 1; dr++) {
        for (let dc = -1; dc <= 1; dc++) {
            if (dr === 0 && dc === 0) continue;
            const r = row + dr;
            const c = col + dc;
            if (isInBounds(r, c)) {
                const piece = chessBoard[r][c];
                if (piece && piece.type === 'k' && piece.color === opponent) return true;
            }
        }
    }

    return false;
}

function wouldBeInCheck(fromRow, fromCol, toRow, toCol) {
    const targetPiece = chessBoard[toRow][toCol];
    const movingPiece = chessBoard[fromRow][fromCol];

    chessBoard[toRow][toCol] = movingPiece;
    chessBoard[fromRow][fromCol] = null;

    const inCheck = isInCheck(currentPlayer);

    chessBoard[fromRow][fromCol] = movingPiece;
    chessBoard[toRow][toCol] = targetPiece;

    return inCheck;
}

function findKing(color) {
    for (let row = 0; row < 8; row++) {
        for (let col = 0; col < 8; col++) {
            const piece = chessBoard[row][col];
            if (piece && piece.type === 'k' && piece.color === color) {
                return { row, col };
            }
        }
    }
    return null;
}

function makeMove(fromRow, fromCol, toRow, toCol) {
    const piece = chessBoard[fromRow][fromCol];
    const target = chessBoard[toRow][toCol];

    if (piece.type === 'k') {
        castlingRights[piece.color].kingSide = false;
        castlingRights[piece.color].queenSide = false;
    }
    if (piece.type === 'r') {
        if (fromRow === (piece.color === 'w' ? 7 : 0)) {
            if (fromCol === 0) castlingRights[piece.color].queenSide = false;
            if (fromCol === 7) castlingRights[piece.color].kingSide = false;
        }
    }

    if (piece.type === 'p' && (toRow === 0 || toRow === 7)) {
        piece.type = 'q';
    }

    if (piece.type === 'p' && enPassantTarget && toRow === enPassantTarget.row && toCol === enPassantTarget.col) {
        chessBoard[fromRow][toCol] = null;
    }

    enPassantTarget = null;
    if (piece.type === 'p' && Math.abs(toRow - fromRow) === 2) {
        enPassantTarget = { row: fromRow + (toRow - fromRow) / 2, col: fromCol };
    }

    if (piece.type === 'k' && Math.abs(toCol - fromCol) === 2) {
        const row = piece.color === 'w' ? 7 : 0;
        if (toCol === 6) {
            chessBoard[row][5] = chessBoard[row][7];
            chessBoard[row][7] = null;
        } else if (toCol === 2) {
            chessBoard[row][3] = chessBoard[row][0];
            chessBoard[row][0] = null;
        }
    }

    chessBoard[toRow][toCol] = piece;
    chessBoard[fromRow][fromCol] = null;
}

function highlightValidMoves(row, col) {
    const validMoves = getValidMoves(row, col);
    const squares = document.querySelectorAll('.chess-square');

    squares.forEach(square => {
        const r = parseInt(square.dataset.row);
        const c = parseInt(square.dataset.col);
        if (validMoves.some(move => move.row === r && move.col === c)) {
            square.classList.add('valid-move');
        }
    });
}

function updateProfileData(newScore) {
    const currentTotal = parseInt(localStorage.getItem('totalScore')) || 0;
    const newTotal = currentTotal + newScore;
    localStorage.setItem('totalScore', newTotal);

    let users = JSON.parse(localStorage.getItem('leaderboard') || '[]');
    const username = localStorage.getItem('username');
    const userIndex = users.findIndex(u => u.name === username);

    if (userIndex !== -1) {
        users[userIndex].score = newTotal;
    } else {
        users.push({ name: username, score: newTotal });
    }

    users.sort((a, b) => b.score - a.score);

    const rank = users.findIndex(u => u.name === username) + 1;
    localStorage.setItem('rank', rank);

    localStorage.setItem('leaderboard', JSON.stringify(users));
}